import flask_login
from flask import Flask, render_template, redirect, request
from flask_login import login_user, LoginManager, \
    current_user, login_required, logout_user
from datetime import datetime

from data.jobs import Jobs
from forms.user import RegisterForm, LoginForm, AddJob
from data.users import User
from data import db_session

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'

login_manager = LoginManager()
login_manager.init_app(app)


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect("/")


@app.route('/del_job/<int:numb>')
def del_job(numb):
    # print(numb)
    sess = db_session.create_session()
    job_tli = sess.query(Jobs).filter(Jobs.id == numb)
    # проверка на id зарег пользователя == 1?
    # так же проверка что id зарег пользователя совпадает
    # с id пользователя, создавшего эту запись
    if flask_login.current_user.id != 1 \
            and flask_login.current_user.id \
            != [x.team_leader for x in job_tli][0]:
        redirect("/")
        return index(message='Вы не можете этого сделать')

    sess.query(Jobs).filter(Jobs.id == numb).delete()
    sess.commit()

    q = 1
    for job in sess.query(Jobs):
        # print(job, job.id, q)
        job.id = q
        q += 1

    sess.commit()

    redirect("/")
    return index()


def main():
    db_session.global_init("db/blogs.db")
    app.run()


@login_manager.user_loader
def load_user(user_id):
    db_sess = db_session.create_session()
    return db_sess.query(User).get(user_id)


@app.route("/")
def index(message=''):
    if not current_user.is_authenticated:
        return redirect('/login')
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs)
    return render_template("index.html", title='Works log',
                           jobs=jobs, message=message)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация', form=form,
                                   message="Такой пользователь уже есть")
        user = User(
            name=form.name.data,
            email=form.email.data,
            about=form.about.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return redirect('/')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db_sess = db_session.create_session()
        user = db_sess.query(User).filter(User.email == form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user, remember=form.remember_me.data)
            return redirect("/")
        return render_template('login.html',
                               message="Неправильный логин или пароль",
                               form=form)
    return render_template('login.html', title='Авторизация', form=form)


@app.route('/addjob', methods=['GET', 'POST'])
def add():
    form = AddJob()
    if form.validate_on_submit():
        if form.team_leader.data and form.job.data and \
                form.work_size.data and form.collaborators.data:
            db_sess = db_session.create_session()

            # print(flask_login.current_user.email)

            job = Jobs(
                team_leader=form.team_leader.data,
                job=form.job.data,
                work_size=form.work_size.data,
                collaborators=form.collaborators.data,
                team_leader_name=flask_login.current_user.name,
                is_finished=form.is_finished.data
            )
            db_sess.add(job)
            db_sess.commit()
            return redirect("/")
        return render_template('add_job.html',
                               message="Заполните поля",
                               form=form)
    return render_template('add_job.html', title='Adding a job', form=form)


@app.route('/edit_job/<int:numb>', methods=['GET', 'POST'])
def edit(numb):
    form = AddJob()
    print(numb)
    sess = db_session.create_session()
    job_tli = sess.query(Jobs).filter(Jobs.id == numb)
    # проверка на id зарег пользователя == 1?
    # так же проверка что id зарег пользователя совпадает
    # с id пользователя, создавшего эту запись
    if flask_login.current_user.id != 1 \
            and flask_login.current_user.id \
            != [x.team_leader for x in job_tli][0]:
        redirect("/")
        return index(message='Вы не можете этого сделать')

    # jobs = sess.query(Jobs).filter(Jobs.id == numb).first()
    # print(jobs, jobs.id)

    if form.validate_on_submit():
        if form.job.data and \
                form.work_size.data \
                and form.collaborators.data:
            # print(flask_login.current_user.email)

            jobs = sess.query(Jobs).filter(Jobs.id == numb).first()
            print(jobs)
            jobs.job = form.job.data
            jobs.work_size = form.work_size.data
            jobs.collaborators = form.collaborators.data
            jobs.is_finished = form.is_finished.data
            sess.commit()
            return redirect("/")
        return render_template('edit_job.html',
                               message="Заполните поля",
                               form=form)
    return render_template('edit_job.html', title='Edit job', form=form)


if __name__ == '__main__':
    main()
